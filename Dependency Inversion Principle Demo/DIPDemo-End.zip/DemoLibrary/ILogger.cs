﻿namespace DemoLibrary
{
    public interface ILogger
    {
        void Log(string message);
    }
}